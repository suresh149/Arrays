import java.util.*;
public class Ex7{
public static void main(String[] args){
	    int arr[]= new int[args.length];
	    LinkedHashSet<Integer> lh=new  LinkedHashSet<Integer>();
	    for(int i=0;i<arr.length;i++)
	    {
	    	arr[i]=Integer.parseInt(args[i]);
	    	lh.add(arr[i]);
	    
	    }
	    for(int a:lh)
	    	System.out.print(a+" ");
		
	}

}