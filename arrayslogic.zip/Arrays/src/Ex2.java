import java.util.*;
public class Ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr={6,-1,-2,-3,0,1,2,3,4};
		Arrays.sort(arr);
		System.out.println("Minimum = " + arr[0]);
		System.out.println("Maximum = " + arr[arr.length-1]);
	}

}
