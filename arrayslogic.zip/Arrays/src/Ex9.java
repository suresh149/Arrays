
public class Ex9
{
  public static void main(String args[])
    {
      int arr[]=new int[args.length];
      int a[]=new int[arr.length];
      int b=0;
      for(int i=0;i<args.length;i++)
      {
         arr[i]=Integer.parseInt(args[i]);
         if(arr[i]!=10)
           {
            a[b]=arr[i];
            b++;
           }
      }
        for(int i=0;i<arr.length;i++)
          System.out.print(a[i]+" ");
  }
}
   